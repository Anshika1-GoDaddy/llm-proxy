# -*- coding: utf-8 -*-

import asyncio
import base64
import json
import logging
import ssl
import sys
from typing import AnyStr, Dict, Optional
from urllib.error import URLError
from urllib.parse import urlparse
from urllib.request import HTTPSHandler, Request, build_opener
from importlib.metadata import version
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.session import Session

import aiohttp

logger = logging.getLogger(__name__)

# Allowed OAuth token endpoint hosts (GoDaddy environments)
ALLOWED_OAUTH_HOSTS = frozenset(
    {
        "api.dev-godaddy.com",  # Dev environment
        "api.test-godaddy.com",  # Test environment
        "api.ote-godaddy.com",  # OTE environment
        "api.godaddy.com",  # Prod environment
    }
)


def validate_oauth_url(url: str) -> None:
    """
    Validate an OAuth URL for scheme and host.

    This validates that:
    1. The URL uses HTTPS scheme (prevents file:// and other dangerous schemes)
    2. The host matches one of the allowed GoDaddy OAuth endpoints

    The path is ignored - only scheme and host are validated.

    Allowed hosts:
        - api.dev-godaddy.com (Dev)
        - api.test-godaddy.com (Test)
        - api.ote-godaddy.com (OTE)
        - api.godaddy.com (Prod)

    Args:
        url: The OAuth URL to validate

    Raises:
        ValueError: If the URL scheme is not HTTPS or host is not allowed
    """
    parsed = urlparse(url)

    # Validate scheme - must be HTTPS for OAuth
    if parsed.scheme.lower() != "https":
        raise ValueError(
            f"Invalid URL scheme '{parsed.scheme}'. Only HTTPS is allowed for OAuth endpoints."
        )

    # Validate hostname exists
    host = parsed.hostname
    if not host:
        raise ValueError("Invalid URL: missing hostname")

    # Validate host is in allowed list
    host_lower = host.lower()
    if host_lower not in ALLOWED_OAUTH_HOSTS:
        raise ValueError(
            f"Invalid OAuth URL host '{host}'. "
            f"Allowed hosts: {', '.join(sorted(ALLOWED_OAUTH_HOSTS))}"
        )


# TIME CONSTANTS
MINUTE_OLD = 60
HOUR_OLD = 60 * 60
DAY_OLD = 24 * HOUR_OLD
WEEK_OLD = 7 * DAY_OLD
MONTH_OLD = 30 * DAY_OLD


def get_url(region: str, sso_host: str) -> str:
    return f"https://iam-token.{region}.{sso_host}/v2/tokens/AWS_IAM"


def get_aws_auth_headers(region: str, url: str, session_credentials: Session) -> dict:
    aws_request = AWSRequest(method="POST", url=url)
    sigv4_credentials = session_credentials.get_frozen_credentials()
    SigV4Auth(sigv4_credentials, "execute-api", region).add_auth(aws_request)
    return dict(aws_request.headers.items())


def safe_get(
    url: str,
    app: str,
    force_heartbeat: bool,
    client_cert: Optional[str] = None,
    client_cert_key: Optional[str] = None,
) -> Dict:
    logger.debug(f"Loading client cert '{client_cert}'")
    user_agent = build_user_agent(app, force_heartbeat)
    # URLErrors might be thrown... so lets try a few times
    retries = 4
    for i in range(retries):  # incase this fails
        try:
            request = Request(url, headers={"User-Agent": user_agent})
            context = ssl.create_default_context()
            if client_cert is not None:
                context.load_cert_chain(client_cert, client_cert_key)

            opener = build_opener(HTTPSHandler(context=context))
            response = opener.open(request).read()
            return json.loads(response.decode())

        except URLError:
            if i == retries - 1:
                logger.error(f"Max retries exceeded. Unable to load client cert '{client_cert}'")
                raise
            logger.debug(f"Retrying load client cert '{client_cert}'")

    # If it hasn't worked yet, give it one more try, else just throw the error
    return json.loads(response.decode())


async def async_safe_get(
    url: str,
    app: str,
    force_heartbeat: bool,
    client_cert: Optional[str] = None,
    client_cert_key: Optional[str] = None,
) -> Dict:
    """Async version of safe_get for fetching certificates."""
    logger.debug(f"Loading client cert '{client_cert}'")
    user_agent = build_user_agent(app, force_heartbeat)
    retries = 4

    ssl_context = ssl.create_default_context()
    if client_cert is not None:
        ssl_context.load_cert_chain(client_cert, client_cert_key)

    last_error: Optional[Exception] = None
    for i in range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"User-Agent": user_agent}
                async with session.get(url, headers=headers, ssl=ssl_context) as response:
                    response.raise_for_status()
                    text = await response.text()
                    return json.loads(text)
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            last_error = e
            if i == retries - 1:
                logger.error(f"Max retries exceeded. Unable to load client cert '{client_cert}'")
                raise URLError(str(e)) from e
            logger.debug(f"Retrying load client cert '{client_cert}'")

    raise URLError(str(last_error)) if last_error else URLError("Unknown error")


def build_user_agent(app: str, force_heartbeat: bool) -> str:
    return (
        f"Python{get_python_ver()} PyAuth{get_pyauth_ver()} App{app} Heartbeat{str(force_heartbeat)}"
    )


def get_python_ver() -> str:
    return f"{sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}"


def get_pyauth_ver() -> str:
    return version("gd-auth")


class EncodingUtils:
    @staticmethod
    def b64decode(payload: AnyStr) -> Optional[bytes]:
        if not payload:
            return None

        decoded_payload = EncodingUtils.decode_to_utf8(payload)
        padded_payload = decoded_payload.ljust(len(payload) + (len(payload) % 4), "=")
        return base64.urlsafe_b64decode(padded_payload.encode("utf-8"))

    @staticmethod
    def rsa_encode(encode_input: AnyStr) -> int:
        return int(base64.b16encode(EncodingUtils.b64decode(encode_input)), 16)

    @staticmethod
    def decode_to_utf8(text: AnyStr) -> str:
        if isinstance(text, str):
            return text  # type: ignore
        else:
            try:
                result = text.decode()  # type: ignore
            except AttributeError:
                result = str(text, encoding="utf-8")  # type: ignore
            return result
