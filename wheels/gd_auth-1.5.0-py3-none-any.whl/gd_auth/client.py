# -*- coding: utf-8 -*-
import asyncio
import datetime as dt

from abc import abstractmethod
from datetime import datetime, timedelta
from json import loads
from logging import getLogger
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from time import sleep
from random import random

import aiohttp

from botocore.session import Session
from gd_auth.utils import get_aws_auth_headers, get_url, validate_oauth_url

from gd_auth.exceptions import (
    OAuthClientError,
    OAuthRateLimitError,
    OAuthServerError,
    SSOClientError,
    SSOError,
    SSORateLimitError,
    SSOServiceError,
)

logger = getLogger(__name__)


class AuthTokenClient(object):
    """
    This class implements the core authentication token client from the SSO team.
    """

    def __init__(self, sso_host: str, refresh_min: float) -> None:
        """
        Constructor to initialize token clients.
        refresh_min = How often to refresh SSO Tokens
        sso_host = The root domain of the host. For example, sso.godaddy.com
        """
        self._sso_host = sso_host
        self._refresh_delta = timedelta(minutes=refresh_min)
        self._token = str()
        self._refresh_time = datetime.now(dt.timezone.utc)

    @abstractmethod
    def _get_token(self) -> str:
        # must be defined by token type specific classes
        raise NotImplementedError("_get_token")

    def _need_refresh(self) -> bool:
        current_time = datetime.now(dt.timezone.utc)
        return current_time >= self._refresh_time

    @property
    def token(self) -> str:
        if not self._token or self._need_refresh():
            logger.info("Fetching new SSO JWT...")
            current_time = datetime.now(dt.timezone.utc)
            self._token = self._get_token()
            self._refresh_time = current_time + self._refresh_delta
            logger.info(f"Successfully retrieved SSO JWT, will be cached until {self._refresh_time}")
        return self._token

    @abstractmethod
    async def _get_token_async(self) -> str:
        # must be defined by token type specific classes
        raise NotImplementedError("_get_token_async")

    async def get_token_async(self) -> str:
        """Async version of token property getter."""
        if not self._token or self._need_refresh():
            logger.info("ASYNC: Fetching new SSO JWT...")
            current_time = datetime.now(dt.timezone.utc)
            self._token = await self._get_token_async()
            self._refresh_time = current_time + self._refresh_delta
            logger.info(
                f"ASYNC: Successfully retrieved SSO JWT, will be cached until {self._refresh_time}"
            )
        return self._token


class AwsIamAuthTokenClient(AuthTokenClient):
    """Handles AWS SigV4 signing and requesting AWS IAM JWTs"""

    def __init__(
        self,
        sso_host: str,
        refresh_min: float = 45.0,
        primary_region: str = "us-west-2",
        secondary_region: str = "us-east-1",
        profile: str = None,
        max_retry_count: int = 5,
        max_retry_wait_time: int = 10,
    ) -> None:
        self._primary_region = primary_region
        self._secondary_region = secondary_region
        self.max_retry_count = max_retry_count
        self.max_retry_wait_time = max_retry_wait_time
        if profile is not None:
            self._session_credentials = Session(profile=profile).get_credentials()
        else:
            self._session_credentials = Session().get_credentials()
        if self._session_credentials is None:
            raise SSOClientError("AWS session credentials not found!")
        (super(AwsIamAuthTokenClient, self).__init__(sso_host=sso_host, refresh_min=refresh_min))

    def _attempt_regional_call(self, region: str) -> str:
        url = get_url(region=region, sso_host=self._sso_host)
        try:
            aws_auth_headers = get_aws_auth_headers(
                region=region, url=url, session_credentials=self._session_credentials
            )
            sso_request = Request(url, method="POST", headers=aws_auth_headers)
            return urlopen(sso_request).read().decode()
        except HTTPError as error:
            if error.code == 429:
                raise SSORateLimitError(
                    f"Failed to retrieve IAM Token, reached IP rate limit : {error.reason}"
                ) from error
            if error.code < 500:
                # This is mostly defensive coding for the unit tests, but just in case
                # the HTTPError doesn't have a .fp response body:
                error_body = error.read() if getattr(error, "fp", None) else ""
                if isinstance(error_body, bytes):
                    error_body = repr(error_body.decode() if error_body else "")
                raise SSOClientError(
                    f"Failed to retrieve IAM Token due to SSO client error: "
                    f"{error.reason} - {error_body}"
                ) from error
            raise SSOServiceError(
                f"Failed to retrieve IAM Token due to SSO service error: {error.reason}"
            ) from error
        except URLError as error:
            raise SSOClientError(f"Bad SSO URL {url} - {error}") from error
        except Exception as error:
            raise SSOClientError(
                f"Failed to retrieve IAM Token due to unknown error: {error}"
            ) from error

    def _get_token_with_retries(self, retry_count: int = 0) -> str:
        try:
            if retry_count > 0:
                timeout_duration = min(2**retry_count + random(), self.max_retry_wait_time)
                logger.warning(f"Retrying in {timeout_duration} seconds...")
                sleep(timeout_duration)
            token = self._get_token_internal()
        except SSOServiceError as error:
            logger.warning(
                f"Failed call to SSO IAM Token Service in {self._secondary_region}: {error}"
            )
            if retry_count < self.max_retry_count:
                token = self._get_token_with_retries(retry_count + 1)
            else:
                raise SSOServiceError(
                    f"Failed to retrieve IAM Token due to SSO service error after {retry_count} retries: {error}"
                ) from error
        return token

    def _get_token_internal(self) -> str:
        try:
            logger.warning(f"Attempting call to SSO IAM Token service in {self._primary_region}...")
            sso_resp = self._attempt_regional_call(self._primary_region)
            return loads(sso_resp)["token"]
        except SSOError as error:
            logger.warning(f"Failed call to SSO IAM Token service in {self._primary_region}: {error}")
            logger.warning(f"Attempting call to SSO IAM Token service in {self._secondary_region}...")
            sso_resp = self._attempt_regional_call(self._secondary_region)
        return loads(sso_resp)["token"]

    def _get_token(self) -> str:
        return self._get_token_with_retries()

    async def _attempt_regional_call_async(self, region: str) -> str:
        """Async version of _attempt_regional_call."""
        url = get_url(region=region, sso_host=self._sso_host)
        try:
            aws_auth_headers = get_aws_auth_headers(
                region=region, url=url, session_credentials=self._session_credentials
            )
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=aws_auth_headers) as response:
                    if response.status == 429:
                        raise SSORateLimitError(
                            f"ASYNC: Failed to retrieve IAM Token, reached IP rate limit : {response.reason}"
                        )
                    if response.status >= 400 and response.status < 500:
                        error_body = await response.text()
                        raise SSOClientError(
                            f"ASYNC: Failed to retrieve IAM Token due to SSO client error: "
                            f"{response.reason} - {error_body}"
                        )
                    if response.status >= 500:
                        raise SSOServiceError(
                            f"ASYNC: Failed to retrieve IAM Token due to SSO service error: {response.reason}"
                        )
                    return await response.text()
        except aiohttp.ClientError as error:
            raise SSOClientError(f"ASYNC: Bad SSO URL {url} - {error}") from error
        except (SSORateLimitError, SSOClientError, SSOServiceError):
            raise
        except Exception as error:
            raise SSOClientError(
                f"ASYNC: Failed to retrieve IAM Token due to unknown error: {error}"
            ) from error

    async def _get_token_with_retries_async(self, retry_count: int = 0) -> str:
        """Async version of _get_token_with_retries."""
        try:
            if retry_count > 0:
                timeout_duration = min(2**retry_count + random(), self.max_retry_wait_time)
                logger.warning(f"ASYNC: Retrying in {timeout_duration} seconds...")
                await asyncio.sleep(timeout_duration)
            token = await self._get_token_internal_async()
        except SSOServiceError as error:
            logger.warning(
                f"ASYNC: Failed call to SSO IAM Token Service in {self._secondary_region}: {error}"
            )
            if retry_count < self.max_retry_count:
                token = await self._get_token_with_retries_async(retry_count + 1)
            else:
                raise SSOServiceError(
                    f"ASYNC: Failed to retrieve IAM Token due to SSO service error after {retry_count} retries: {error}"
                ) from error
        return token

    async def _get_token_internal_async(self) -> str:
        """Async version of _get_token_internal."""
        try:
            logger.warning(
                f"ASYNC: Attempting call to SSO IAM Token service in {self._primary_region}..."
            )
            sso_resp = await self._attempt_regional_call_async(self._primary_region)
            return loads(sso_resp)["token"]
        except SSOError as error:
            logger.warning(
                f"ASYNC: Failed call to SSO IAM Token service in {self._primary_region}: {error}"
            )
            logger.warning(
                f"ASYNC: Attempting call to SSO IAM Token service in {self._secondary_region}..."
            )
            sso_resp = await self._attempt_regional_call_async(self._secondary_region)
        return loads(sso_resp)["token"]

    async def _get_token_async(self) -> str:
        """Async version of _get_token."""
        return await self._get_token_with_retries_async()


class OAuthTokenClient(AuthTokenClient):
    """
    OAuth 2.0 Token Client for requesting tokens using client credentials grant.

    Example usage:
        client = OAuthTokenClient(
            token_endpoint="https://api.godaddy.com/v2/oauth2/token",
            client_id="your-client-id",
            client_secret="your-client-secret",
            scope="your.scope:permission"
        )
        token = client.token  # Auto-refreshes when expired
    """

    def __init__(
        self,
        token_endpoint: str,
        client_id: str,
        client_secret: str,
        scope: str,
        refresh_min: float = 45.0,
        max_retry_count: int = 3,
        max_retry_wait_time: int = 10,
    ) -> None:
        """
        Initialize the OAuth Token Client.

        Args:
            token_endpoint: OAuth token endpoint URL (e.g., https://api.godaddy.com/v2/oauth2/token)
            client_id: OAuth client ID
            client_secret: OAuth client secret
            scope: OAuth scope(s) to request (space-separated if multiple)
            refresh_min: Minutes before token refresh (default: 45 minutes)
            max_retry_count: Maximum retry attempts on server errors (default: 3)
            max_retry_wait_time: Maximum wait time between retries in seconds (default: 10)
        """
        self._token_endpoint = token_endpoint
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self.max_retry_count = max_retry_count
        self.max_retry_wait_time = max_retry_wait_time

        super(OAuthTokenClient, self).__init__(sso_host="", refresh_min=refresh_min)

    def _request_token(self) -> str:
        """
        Make OAuth token request using client credentials grant.

        Returns:
            Access token string

        Raises:
            OAuthClientError: For client-side errors (4xx)
            OAuthServerError: For server-side errors (5xx)
            OAuthRateLimitError: When rate limited (429)
            ValueError: If the token endpoint uses an invalid URL scheme or host
        """
        # Validate OAuth URL (scheme and host) to prevent SSRF attacks
        validate_oauth_url(self._token_endpoint)

        # Prepare request data
        data = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "scope": self._scope,
        }

        encoded_data = urlencode(data).encode("utf-8")
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        request = Request(
            self._token_endpoint,
            data=encoded_data,
            method="POST",
            headers=headers,
        )

        try:
            response = urlopen(request, timeout=30)
            response_data = loads(response.read().decode("utf-8"))

            if "access_token" not in response_data:
                raise OAuthClientError("OAuth response missing 'access_token'")

            expires_in = response_data.get("expires_in", 3600)
            logger.info(f"Successfully obtained OAuth token (expires_in: {expires_in}s)")

            return response_data["access_token"]

        except HTTPError as error:
            error_body = ""
            if getattr(error, "fp", None):
                raw_body = error.read()
                error_body = raw_body.decode("utf-8") if raw_body else ""

            if error.code == 429:
                raise OAuthRateLimitError(f"OAuth rate limit exceeded: {error.reason}") from error

            if error.code < 500:
                raise OAuthClientError(
                    f"OAuth client error ({error.code}): {error.reason} - {error_body}"
                ) from error

            raise OAuthServerError(
                f"OAuth server error ({error.code}): {error.reason} - {error_body}"
            ) from error

        except URLError as error:
            raise OAuthClientError(f"Failed to connect to OAuth server: {error}") from error

        except Exception as error:
            raise OAuthClientError(f"Unexpected error requesting OAuth token: {error}") from error

    def _get_token_with_retries(self, retry_count: int = 0) -> str:
        """Request token with exponential backoff retry on server errors."""
        try:
            if retry_count > 0:
                timeout_duration = min(2**retry_count + random(), self.max_retry_wait_time)
                logger.warning(f"Retrying OAuth token request in {timeout_duration:.1f} seconds...")
                sleep(timeout_duration)
            return self._request_token()

        except OAuthServerError as error:
            logger.warning(f"OAuth server error: {error}")
            if retry_count < self.max_retry_count:
                return self._get_token_with_retries(retry_count + 1)
            raise OAuthServerError(
                f"Failed to retrieve OAuth token after {retry_count} retries: {error}"
            ) from error

    def _get_token(self) -> str:
        """Get OAuth token (called by base class)."""
        return self._get_token_with_retries()
